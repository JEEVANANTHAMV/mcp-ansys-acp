# Ansys ACP (Additive Composite Process) MCP

Per-product offline MCP server. See SKILL.md for usage.

* pip client: ansys-acp-core
* top-level import: ansys.acp
* kind: grpc
* env: ANSYS_ROOT
